import requests
import re


def extract(mblog):
    url_names = []
    if 'pics' in mblog.keys():
        pics = [pic['large']['url'] for pic in mblog['pics']]
        # for image
        for pic in pics:
            img_name=''
            if '?KID=' in pic:
                img_name = re.compile(
                    '.*?KID=').findall(pic.split('/')[-1])[0][:-5]
            else:
                img_name = pic.split('/')[-1]
            url_names.append((pic,img_name))
    return url_names
