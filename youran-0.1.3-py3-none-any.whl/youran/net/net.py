import requests
from . import headers
import time
import tqdm
import io
import random
import youran
def get(url,cookie=False,header='pc',proxy=True):
    # print(url)
    cookies=headers.cookies if cookie else None
    # tunnel = random.randint(1,10000)
    headers1 =headers.pc if header == 'pc' else headers.mobile
    # headers1["Proxy-Tunnel"]=str(tunnel)
    _proxies=youran.db.proxy.get_randomip() if proxy else None
    print(cookies,_proxies)
    r=requests.get(url, headers=headers1,cookies=cookies,verify=False,proxies=_proxies,timeout=30)
    # r.encoding = r.apparent_encoding
    return r.text

# def download(url,proxy=None):
#     # print(url)
#     # time.sleep(15)
#     # if '403 Forbidden' in get(url):
#     #     return None
#     response=requests.get(url, headers=headers.pc, stream=True,timeout=30,verify=False,proxies=proxies.get_randomip())
#     if response.status_code!=200:
#         return None
#     file_size=response.headers['Content-length']
#     pbar=tqdm.tqdm(total=int(file_size),unit='B',unit_scale=True,desc=url.split('/')[-1][:20])
#     with io.BytesIO() as f:
#         for chunk in response.iter_content(chunk_size=1024):
#             if  chunk:
#                 f.write(chunk)
#                 pbar.update(1024)
#         return f.getvalue()
#     pbar.close()
def download(url,progress=False):
    # print(url)
    # time.sleep(15)
    # if '403 Forbidden' in get(url):
    #     return None
    response=requests.get(url, headers=headers.mobile, stream=True,timeout=30,verify=False,proxies=youran.db.proxy.get_randomip())
    if response.status_code!=200:
        return None
    if 'Content-length' not in response.headers:
        return None
    file_size=response.headers['Content-length']
    pbar=None
    if progress:
        pbar=tqdm.tqdm(total=int(file_size),unit='B',unit_scale=True,desc=url.split('/')[-1][:20])
    with io.BytesIO() as f:
        for chunk in response.iter_content(chunk_size=1024):
            if  chunk:
                f.write(chunk)
                if progress:
                    pbar.update(1024)
        pbar.close()
        return f.getvalue()
    
if __name__=='__main__':
    download('http://122.51.50.206:8088/imgs/63943f53ly1gjgojmh9zaj222o0yi7wq.jpg')