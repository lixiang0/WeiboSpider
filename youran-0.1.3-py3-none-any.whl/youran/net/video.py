
import re
import urllib


def extract(mblog):
    # 解析视频地址video:mblog['mblog']['page_info']['media_info']['stream_url']
    # 字段的示例参考10.×.py文件
    object_id = ''
    if 'page_info' in mblog.keys():
        if mblog['page_info']['type'] == 'video':
            object_id = mblog['page_info']['object_id']
            # for video
            if len(object_id) > 2:
                # f'https://m.weibo.cn/status/{bid}?fid={object_id}'
                if 'media_info' not in mblog['page_info'].keys():
                    return
                video_url = mblog['page_info']['media_info']['stream_url']
                video_name = ''
                if video_url is not ' ' and video_url is not '':
                    # http://flv.bn.netease.com/videolib3/1602/25/DCmck9663/HD/DCmck9663-mobile.mp4
                    if 'cntv.vod.cdn.myqcloud.com' in video_url or 'flv.bn.netease.com' in video_url:
                        video_name = video_url.split('/')[-1]
                    # http://miaopai.video.weibocdn.com/y8uhGmpklx07hgllSbT20104020118Td0E013?Expires=1580820449&ssig=Tyclwn1zHP&KID=unistore,video
                    # http://miaopai.video.weibocdn.com/004isPQTlx07w78L1b5S010412010UgY0E013.mp4?label=mp4_hd&template=852x480.24.0&trans_finger=ac6fb6d5c49a67fe2901ae638b222ab2&Expires=1580806190&ssig=YrHlNViWdZ&KID=unistore,video
                    elif 'miaopai.video.weibocdn.com' in video_url:
                        if '?Expires=' in video_url:
                            video_name = re.compile(
                                '.*?Expires').findall(video_url)[0].split('/')[-1][:-8]+'.mp4'
                        if '.mp4?label=mp4_hd' in video_url:
                            video_name = re.compile(
                                '.*.mp4\?').findall(video_url)[0][:-1].split('/')[-1]
                    # http://api.ivideo.sina.com.cn/public/video/play/url?appname=weibocard&appver=0.1&applt=web&tags=weibocard&direct=1&vid=32183307201
                    elif 'api.ivideo.sina.com.cn' in video_url:  # 需要redirect
                        video_url = urllib.request.urlopen(
                            video_url).geturl()  # redirect之后再解析
                        mblog['page_info']['media_info']['stream_url'] = video_url
                        res = re.findall('n/(.*).(mp4|m3u8)\?', video_url)[0]
                        video_name = res[0]+'.'+res[1]
                    # https://us.sinaimg.cn/0048hC0kjx06YLljHDni010d0100006H0k01.m3u8?KID=unistore,video&Expires=1582024223&ssig=Kbnro7UusO&KID=unistore,video
                    # https://us.sinaimg.cn/0023jkOujx07bacCMKDK010f1100fYwu0k01.mp4?label=mp4_hd&Expires=1582079291&ssig=4wjkt3+R4g&KID=unistore,video,开始下载
                    elif 'https://us.sinaimg.cn' in video_url:
                        video_name = re.findall('n/(.*).(mp4|m3u8)\?',video_url)
                        video_name=video_name[0][0]+'.'+video_name[0][1]
                    # https://api.youku.com/videos/player/file?data=WcEl1oUuTdTROalV5T0RFd09BPT18MHwxfDEwMDUw
                    elif 'https://api.youku.com' in video_url:
                        video_name = video_url.split('data=')[1]+'.mp4'
                    # http://edge.ivideo.sina.com.cn/96148152.mp4?KID=sina,viask&Expires=1582214400&ssig=TafyOUtj%2Ff
                    elif 'edge.ivideo.sina.com.cn' in video_url:
                        video_name = re.findall(
                            '/(.*).mp4', video_url)[0]+'.mp4'
                    # http://mvvideo2.meitudata.com/581e9c3a91f903898.mp4
                    elif 'http://mvvideo2.meitudata.com' in video_url:#/581e9c3a91f903898.mp4
                        video_name=re.findall('m/(.*).(mp4|m3u8)',video_url)[0]
                        video_name=video_name[0]+'.'+video_name[1]
                    else:
                        video_name = re.compile(
                            r'.*.mp4\?').findall(video_url.split('/')[-1])
                        if len(video_name) > 0:
                            video_name = video_name[0][:-1]
                        else:
                            video_name = 'None.mp4'
                    return video_url,video_name
    return None,None

if __name__=='__main__':
    # https://weibo.com/tv/show/1034:4668720199696422?from=old_pc_videoshow
    # https://video.weibo.com/show?fid=1034:4668720199696422
    ss={'_id': '4669445920785354', 'alchemy_params': {'ug_red_envelope': False}, 'attitudes_count': 2993, 'bid': 'Kt8By3ij0', 'can_edit': False, 'comments_count': 1090, 'content_auth': 0, 'created_at': 'Thu Aug 12 19:02:04 +0800 2021', 'darwin_tags': [], 'edit_config': {'edited': False}, 'enable_comment_guide': True, 'extern_safe': 0, 'favorited': False, 'fid': 4669365235744804, 'hide_flag': 0, 'id': '4669445920785354', 'isLongText': False, 'is_paid': False, 'mblog_menu_new_style': 0, 'mblog_vip_type': 0, 'mblogtype': 0, 'mid': '4669445920785354', 'mlevel': 0, 'more_info_type': 0, 'page_info': {'type': 'video', 'object_type': 11, 'url_ori': 'http://t.cn/A6If5bxO', 'page_pic': {'width': 3840, 'pid': '006EPFJBly1gtdypkv05yj31hc0u0qdv', 'source': 1, 'is_self_cover': 1, 'type': 1, 'url': 'https://wx1.sinaimg.cn/crop.0.6.1920.1067/006EPFJBly1gtdypkv05yj31hc0u0qdv.jpg', 'height': 2134}, 'page_url': 'https://video.weibo.com/show?fid=1034%3A4669364654506010&luicode=10000011&lfid=1076036100165591', 'object_id': '1034:4669364654506010', 'page_title': '刘老师说电影的微博视频', 'title': '人类内斗起来，就没丧尸什么事了！', 'content1': '刘老师说电影的微博视频', 'content2': '女王行为！卡妈归来战斗力 爆表！刘老师爆笑解说《行尸走肉》第五季#金牌解说#', 'video_orientation': 'horizontal', 'play_count': '55万次播放', 'media_info': {'stream_url': 'https://f.video.weibocdn.com/adxR1qiDlx07OY1AlMju01041201zEhu0E010.mp4?label=mp4_ld&template=640x360.25.0&trans_finger=6006a648d0db83b7d9951b3cee381a9c&ori=0&ps=1CwnkDw1GXwCQx&Expires=1628797484&ssig=512JDqskaZ&KID=unistore,video', 'stream_url_hd': 'https://f.video.weibocdn.com/sgZneB4ulx07OY1ARW4U01041202rTvG0E010.mp4?label=mp4_hd&template=852x480.25.0&trans_finger=d8257cc71422c9ad30fe69ce9523c87b&ori=0&ps=1CwnkDw1GXwCQx&Expires=1628797484&ssig=9qUZDCePCC&KID=unistore,video', 'duration': 660.096}, 'urls': {'mp4_720p_mp4': 'https://f.video.weibocdn.com/StjmUUb5lx07OY1BLztC01041204KTK50E020.mp4?label=mp4_720p&template=1280x720.25.0&trans_finger=775cb0ab963a74099cf9f840cd1987f1&ori=0&ps=1CwnkDw1GXwCQx&Expires=1628797484&ssig=CYaUkAPYYH&KID=unistore,video', 'mp4_hd_mp4': 'https://f.video.weibocdn.com/sgZneB4ulx07OY1ARW4U01041202rTvG0E010.mp4?label=mp4_hd&template=852x480.25.0&trans_finger=d8257cc71422c9ad30fe69ce9523c87b&ori=0&ps=1CwnkDw1GXwCQx&Expires=1628797484&ssig=9qUZDCePCC&KID=unistore,video', 'mp4_ld_mp4': 'https://f.video.weibocdn.com/adxR1qiDlx07OY1AlMju01041201zEhu0E010.mp4?label=mp4_ld&template=640x360.25.0&trans_finger=6006a648d0db83b7d9951b3cee381a9c&ori=0&ps=1CwnkDw1GXwCQx&Expires=1628797484&ssig=512JDqskaZ&KID=unistore,video'}}, 'pending_approval_count': 0, 'pic_ids': [], 'pic_num': 0, 'pic_types': '', 'reposts_count': 875, 'reward_exhibition_type': 0, 'rid': '1_0_50_4813850309442391440_0_0_0', 'show_additional_indication': 0, 'source': '微博视频号', 'spider_time': 1628793955.97164, 'text': '女王行为！卡妈归来战斗力爆表！刘老师 爆笑解说《行尸走肉》第五季<a  href="https://m.weibo.cn/search?containerid=231522type%3D1%26t%3D10%26q%3D%23%E9%87%91%E7%89%8C%E8%A7%A3%E8%AF%B4%23&luicode=10000011&lfid=1076036100165591" data-hide=""><span class="surl-text">#金牌解说#</span></a> <a data-url="http://t.cn/A6If5bxO" href="https://video.weibo.com/show?fid=1034:4669364654506010" data-hide=""><span class=\'url-icon\'><img style=\'width: 1rem;height: 1rem\' src=\'https://h5.sinaimg.cn/upload/2015/09/25/3/timeline_card_small_video_default.png\'></span><span class="surl-text">刘老师说电影的微博视频</span></a> ', 'textLength': 93, 'uid': 6100165591, 'user': {'id': 6100165591, 'screen_name': '刘老师说电影', 'profile_image_url': 'https://tvax2.sinaimg.cn/crop.0.0.1080.1080.180/006EPFJBly8gditlvnl62j30u00u0tae.jpg?KID=imgbed,tva&Expires=1628804684&ssig=sb6oTG9jY1', 'profile_url': 'https://m.weibo.cn/u/6100165591?uid=6100165591&luicode=10000011&lfid=1076036100165591', 'statuses_count': 976, 'verified': True, 'verified_type': 0, 'verified_type_ext': 1, 'verified_reason': '微博2019十大影响力电影视频博主 电影视频自媒体', 'close_blue_v': False, 'description': '微博2018十大影响力电影大V 电影视频自媒体', 'gender': 'm', 'mbtype': 12, 'urank': 32, 'mbrank': 7, 'follow_me': False, 'following': False, 'followers_count': 5177562, 'follow_count': 275, 'cover_image_phone': 'https://wx1.sinaimg.cn/crop.0.0.640.640.640/006EPFJBly1flojft1118j30yi0yhmyw.jpg', 'avatar_hd': 'https://wx2.sinaimg.cn/orj480/006EPFJBly8gditlvnl62j30u00u0tae.jpg', 'like': False, 'like_me': False, 'badge': {'bind_taobao': 1, 'follow_whitelist_video': 1, 'video_attention': 4, 'user_name_certificate': 1, 'wenchuan_10th': 1, 'super_star_2018': 1, 'weibo_display_fans': 1, 'relation_display': 1, 'v_influence_2018': 1, 'hongbaofei_2019': 1, 'hongrenjie_2019': 1, 'rrgyj_2019': 1, 'weishi_2019': 1, 'gongjiri_2019': 1, 'hongbao_2020': 2, 'pc_new': 6, 'hongrenjie_2020': 1, 'nihaoshenghuojie_2021': 1}}, 'version': 2, 'visible': {'type': 0, 'list_id': 0}}
    print(extract(ss))
    pass