from . import net
import json

def get(mblog,cookie=True,proxy=False):
    mid=mblog['mid']
    comment_url=f'https://m.weibo.cn/comments/hotflow?id={mid}&mid={mid}&max_id_type=0'
    try:
        comment_text_response = net.get(comment_url,cookie=cookie,proxy=proxy)
        # print(res)
        if '微博-出错了' in comment_text_response:
            return None
        comments=json.loads(comment_text_response)
        comments['mid']=mid
        comments['_id']=mid
        return comments
    except Exception as e:
        return None #网络错误


def extract_img(comments):
    urls_name=[]
    if 'data' in comments.keys():
        pics=comments['data']['data']
        if len(pics)>0:
            for pic in pics:
                # print(pic)
                if 'pic' in pic.keys():
                    name=pic['pic']['pid']
                    img_url=pic['pic']['large']['url']
                    urls_name.append((img_url,name))
            # return urls_name
    return urls_name