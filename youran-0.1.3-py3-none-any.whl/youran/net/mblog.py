
import requests
from . import net
import json
import re

# different user return different item for every page


def extract_mblogs(uid, page=1,cookie=False,proxy=False):
    # page_url=f'https://weibo.com/ajax/statuses/mymblog?uid={uid}&page={page}&feature=0'
    page_url = f'https://m.weibo.cn/api/container/getIndex?uid={uid}&lfid=2304136390144374_-_WEIBO_SECOND_PROFILE_WEIBO&containerid=107603{uid}'
    next_url = page_url+f'&page={page}' if page > 1 else page_url
    obj=None
    try:
        # print('next_url:',next_url)
        res = net.get(next_url,cookie=cookie,proxy=proxy)
        # print(res)
        if '100005' in res:
            return -2,'请求过于频繁' #请求过于频繁
        obj=json.loads(res)
    except Exception as e:
        return -3,repr(e) #网络错误
    # print(res)
    total_mblogs = 0
    mblogs = []
    if obj['ok'] == 1:
        cards = obj['data']['cards']
        total_mblogs = obj['data']['cardlistInfo']['total']
        for card in cards:
            # print(card)
            if not 'mblog' in card:
                continue
            mblog = card['mblog']
            # mblog.pop('user')
            mblogs.append(mblog)

    else:
        return -1,obj #可能需要重新登录
    return total_mblogs, mblogs

# https://m.weibo.cn/feed/friends?max_id=4589611853288529:
def extract_feeds(maxbid=None):
    page_url = f'https://m.weibo.cn/feed/friends'
    if maxbid is not None:
        page_url+=f'?max_id={maxbid}'
    res = net.get(page_url,cookie=True)
    if '请求过于频繁,歇歇吧' in res:
        return -1, -1
    obj = json.loads(res)
    print(page_url)
    max_bid=obj['data']['max_id']
    mblogs = []
    if obj['ok'] == 1:
        cards = obj['data']['statuses']
        for card in cards:
            # print(card)

            # mblog.pop('user')
            mblogs.append(card)
    else:
        return -1,-1
    return max_bid, mblogs

def get(mblog,cookie=False,proxy=False):
    # 对于长微博需要跳转具体微博，才能查看全部内容
    # https://m.weibo.cn/detail/{mid}
    # https://m.weibo.cn/status/{bid}
    mid = mblog['bid']
    res = mblog
    # print(res)
    if 'isLongText' in mblog and mblog['isLongText']:
        long_text_url = 'https://m.weibo.cn/status/'+str(mid)
        long_text_response= None
        try:
            long_text_response= net.get(long_text_url,cookie=cookie,proxy=proxy)
        except Exception as e:
            return None, None
        res = re.compile(
            r'var\ \$render_data = \[\{.*\}\]\[0\]\ \|\|\ \{\};', re.DOTALL).findall(long_text_response)
        if len(res) < 1:
            return None, None
        res = json.loads(str(res[0].replace('\n', '')[20:-11]))['status']
    # print(res)
    # print(res.keys())
    # res['uid'] = res['user']['id']
    res['_id'] = res['mid']
    return res


# if __name__ == "__main__":
#     print(extract_feeds( maxbid=None))
