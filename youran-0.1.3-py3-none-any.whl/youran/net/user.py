
from . import net
import json

def get(id):
    res = net.get(f'https://m.weibo.cn/profile/info?uid={id}')
    if '用户不存在' in res:
        return None
    obj = json.loads(res)
    if obj['ok'] == 1:
        user = obj['data']['user']
        user['_id'] = id
        return user
    else:
        return None