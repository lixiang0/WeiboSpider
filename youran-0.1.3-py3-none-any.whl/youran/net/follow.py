
from . import net
import json

def get(uid, page=1):
    follows_url = f'https://m.weibo.cn/api/container/getIndex?containerid=231051_-_followers_-_{uid}_-_1042015:tagCategory_019'
    next_url = follows_url+f'&page={page}' if page > 1 else follows_url
    res = net.get(next_url)
    obj = json.loads(res)
    # print(obj)
    if obj['ok'] == 1:
        users=[]
        cards = obj['data']['cards']
        total = obj['data']['cardlistInfo']['total']
        # print(total)
        for card in cards:
            for item in card['card_group']:
                # print(item)
                if 'user' in item.keys():
                    user = item['user']
                    if user is None:
                        return None,None
                    user['_id'] = user['id']
                    users.append(user)
        return total,users
    return None,None
