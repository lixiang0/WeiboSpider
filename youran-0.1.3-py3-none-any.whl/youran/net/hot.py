# https://weibo.com/ajax/statuses/hot_band
from . import net
import json
import time,re
from scrapy.selector import Selector
def get():
    hot_url='https://weibo.com/a/hot/realtime'
    hot_text_response = net.get(hot_url,header='pc',cookie=True)
    lists=Selector(text=hot_text_response).xpath('//div[@node-type="feed_list"]').xpath('//div[@action-type="feed_list_item"]').getall()
    if len(lists)==0:
        return None
    results=[]
    items=[]
    for li in lists:
        text=Selector(text=li).xpath('//a[@class="S_txt1"]/text()').get()
        href=Selector(text=li).xpath('//a[@class="S_txt1"]').attrib['href']
        url,bids=_get_detail(href)
        # print(text,href)
        results.append((text,url.split('/')[-1],bids))
    return results
def _get_detail(url):
    # print(url)
    url='https://weibo.com/a/hot/'+url if '/a/hot/' not in url else 'https://weibo.com'+url
    detail_response=net.get(url,header='pc',cookie=True)
    lists=Selector(text=detail_response).xpath('//div[@node-type="feed_list"]').xpath('//div[@action-type="feed_list_item"]').getall()
    if len(lists)==0:
        return None
    bids=[]
    # print(url)
    for li in lists:
        _=Selector(text=li).xpath('//div[@href]').attrib['href']
        _=re.findall('[0-9]+/[0-9a-z-A-z]+',_)
        bid=_[0].split('/')[-1] if len(_)==1 else None
        if bid is None:
            continue
        bids.append(bid)
    # print(detail_response)
    return url,bids

def extract_img(comments):
    urls_name=[]
    if 'data' in comments.keys():
        pics=comments['data']['data']
        if len(pics)>0:
            for pic in pics:
                # print(pic)
                if 'pic' in pic.keys():
                    name=pic['pic']['pid']
                    img_url=pic['pic']['large']['url']
                    urls_name.append((img_url,name))
            # return urls_name
    return urls_name

if __name__ =="__main__":
    print(get())