import random,json,pymongo,youran

db_proxies = youran.db_proxy['db_proxy']

def get_randomip():
    ip=list(db_proxies.aggregate([{'$sample': {'size': 2}}]))[0]
    # print(ip['ip'])
    if 'https' in ip['niming']:
        return {'https': f"https://{ip['ip']}"}
    else:
        return {'http': f"http://{ip['ip']}"}
if __name__=='__main__':
    # print(get_randomip())
    import requests
    proxies = get_randomip()
    text=requests.get("https://weibo.cn/", proxies=proxies,verify=False,timeout=2).text
    import re
    print(text)
    print(re.findall('IP/域名\d+\.\d+.\d+\.\d',text))