import pymongo
import youran
import time
db_hotids = youran.db_client['db_hotids']

def find_ids(url):
    return db_hotids.find({'_id':url})

# def find_hot_count(mid):
#     return db_hot.find({'mid': mid}).count()
# def exists(mid):
#     return db_hot.find({'mid': mid}).count()>0

def add(hotids):
    try:
        db_hotids.update({'_id': hotids['url']}, {
            '$set': hotids}, upsert=True)
        return True
    except pymongo.errors.DuplicateKeyError:
        return False