import pymongo
import youran


db_user = youran.db_client['db_user']


def add_user(user):
    try:
        db_user.update({'_id': user['_id']}, {
            '$set': user}, upsert=True)
        return True
    except pymongo.errors.DuplicateKeyError:
        return False

def find_user(id):
    return db_user.find_one({'_id': id})
def find_users(ids):
    return db_user.find({"_id": {"$in": ids}}).sort('_id', direction=-1)

def random(size=10):
    import random
    return list(db_user.find({}).limit(size).skip(int(random.random()*db_user.estimated_document_count())))
    # return list(db_user.aggregate([{'$sample': {'size': size}}]))
def count():
    return db_user.count()

if __name__ == "__main__":
    import time
    pre=time.time()
    # print(count())
    # print(random())
    print(find_user(6347862377))
    print(time.time()-pre)
    # pre=time.time()
    # print(random().next())
    # print(time.time()-pre)
    