import pymongo
import youran  

db_follower = youran.db_client['db_follower']

#_id=uid+blogger_id    fans:uid  blogger: blogger_id
# {'_id': str(uid)+str(user['id']), 'fans': int(uid), 'blogger': int(user['id'])}
def add(obj):
    try:
        db_follower.insert_one(obj)
        return True
    except pymongo.errors.DuplicateKeyError:
        return False
def delete(obj):
    return db_follower.delete_one(obj)
def find(obj):
    return db_follower.find_one(obj)
def all_follows():
    return set([d['fans'] for d in db_follower.find({}, {'fans': 1, '_id': 0})])

def all_bloggers():
    return set([d['blogger'] for d in db_follower.find({}, {'blogger': 1, '_id': 0})])

def follows(id):
    # db.db_follower.find({'_id':{$regex:'^10029[0-9]+'}})
    # return list(set([d['blogger'] for d in db_follower.find({'fans': id})]))
    return list(set([d['blogger'] for d in db_follower.find({'_id':{'$regex':f'^{id}[0-9]+'}})]))

def random_follows(size=10):
    return list(db_follower.aggregate([{'$sample': {'size': size}}]))




if __name__ == "__main__":
    import time
    pre=time.time()
    print(follows(1746493725))
    print(time.time()-pre)
    pre=time.time()
    print(random_follows())
    print(time.time()-pre)
