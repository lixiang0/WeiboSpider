import pymongo
import youran
import time,json
db_mblogs = youran.db_client['db_mblogs']


def pages( uid):
    return int((db_mblogs.find({'uid': uid}).count())/10)

def add(obj):
    obj['spider_time']:time.time()
    try:
        db_mblogs.update({'_id': obj['_id']}, {
            '$set': obj}, upsert=True)
        return True
    except pymongo.errors.DuplicateKeyError:
        return False

def count(uid):
    return db_mblogs.find({'uid': uid}).count()

def random(nums):
    return list(db_mblogs.aggregate([{'$sample': {'size': nums}}]))
def find():
    return db_mblogs.find({})
def exists(bid):
    return db_mblogs.find({'bid': bid}).count()>0
def counts():
    count=db_mblogs.find({}).count()
    authors=len(db_mblogs.distinct('uid'))
    return count,authors
# The return type must be a string, dict, tuple, Response instance, or WSGI callable,
def latest(ids,page=0):
    # ids.remove(1981438770)
    result=db_mblogs.find({"uid": {"$in": ids}}).sort('created_at1', direction=-1).skip(int(page*20)).limit(20)
    return result
def bids(bids):
    return db_mblogs.find({"bid": {"$in": bids}}).sort('_id', direction=-1)
if __name__ == "__main__":
    # print(count(1979899604))
    # print(random(5))
    # print(exists('EjUN8zUW9'))
    print(latest([1979899604]).next())