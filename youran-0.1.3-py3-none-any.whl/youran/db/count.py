import pymongo
import youran
db_count = youran.db_client['db_count']


def add_user(user):
    try:
        db_count.update({'_id': user['_id']}, {
            '$set': user}, upsert=True)
        return True
    except pymongo.errors.DuplicateKeyError:
        return False

def find_user(uname):
    return db_count.find_one({'uname': uname})
def find_users(ids):
    return db_count.find({"_id": {"$in": ids}}).sort('_id', direction=-1)

def random(size=10):
    import random
    return list(db_count.find({}).limit(size).skip(int(random.random()*db_count.estimated_document_count())))
    # return list(db_count.aggregate([{'$sample': {'size': size}}]))
def count():
    return db_count.estimated_document_count()

if __name__ == "__main__":
    import time
    pre=time.time()
    # print(count())
    # print(random())
    print(find_user(6347862377))
    print(time.time()-pre)
    # pre=time.time()
    # print(random().next())
    # print(time.time()-pre)
    