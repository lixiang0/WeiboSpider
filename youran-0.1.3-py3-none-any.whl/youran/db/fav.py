import pymongo
import youran


db_fav = youran.db_client['db_fav']


def add(obj):
    try:
        db_fav.update({'_id': obj['uid']+'$'+obj['bid']}, {
            '$set': obj}, upsert=True)
        return True
    except pymongo.errors.DuplicateKeyError:
        return False
def delete(obj):
    return db_fav.delete_one(obj)
def find(obj):
    return db_fav.find_one(obj)
def bids(uid):
    # ids.remove(1981438770)
    result=db_fav.find({'uid':uid})
    return result
def random(size=10):
    import random
    return list(db_fav.find({}).limit(size).skip(int(random.random()*db_fav.estimated_document_count())))
    # return list(db_fav.aggregate([{'$sample': {'size': size}}]))
def count():
    return db_fav.estimated_document_count()

if __name__ == "__main__":
    import time
    pre=time.time()
    # print(count())
    # print(random())
    print(find_user(6347862377))
    print(time.time()-pre)
    # pre=time.time()
    # print(random().next())
    # print(time.time()-pre)
    