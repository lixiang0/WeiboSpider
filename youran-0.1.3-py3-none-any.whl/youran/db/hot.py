import pymongo
import youran
import time
db_hot = youran.db_client['db_hot']

def find_hot():
    return db_hot.find({}).sort('_id', direction=-1).limit(1)

# def find_hot_count(mid):
#     return db_hot.find({'mid': mid}).count()
# def exists(mid):
#     return db_hot.find({'mid': mid}).count()>0

def add(hot):
    try:
        db_hot.update({'_id': time.time()}, {
            '$set': hot}, upsert=True)
        return True
    except pymongo.errors.DuplicateKeyError:
        return False