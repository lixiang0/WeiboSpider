import pymongo
import youran

db_comments = youran.db_client['db_comments']

def find_comments(mid):
    return db_comments.find_one({'mid': mid})

def find_comments_count(mid):
    return db_comments.find({'mid': mid}).count()
def exists(mid):
    return db_comments.find({'mid': mid}).count()>0

def add(comments):
    try:
        db_comments.update({'_id': comments['_id']}, {
            '$set': comments}, upsert=True)
        return True
    except pymongo.errors.DuplicateKeyError:
        return False