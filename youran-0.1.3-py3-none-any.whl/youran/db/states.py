import pymongo
import youran


db_states = youran.db_client['db_states']


def add(obj):
    try:
        db_states.update({'_id': obj['name']}, {
            '$set': obj}, upsert=True)
        return True
    except pymongo.errors.DuplicateKeyError:
        return False
def delete(obj):
    return db_states.delete_one(obj)
def find(obj):
    return db_states.find_one(obj)
def finds():
    return db_states.find({})

def count():
    return db_states.count()

if __name__ == "__main__":
    import time
    pre=time.time()
    # print(count())
    # print(random())
    print(add({'name':'my_feeds','update_time':time.asctime( time.localtime(time.time()) )}))
    print(time.time()-pre)
    # pre=time.time()
    # print(random().next())
    # print(time.time()-pre)
    