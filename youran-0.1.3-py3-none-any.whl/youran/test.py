# from net import follow

# follow.get('1746493725')
# from db import hot
import utils
# print(list(hot.get()))
utils.download_hot()
# for h in hot.find_hot():
#     print(h)