import os

# IP=None#192.168.1.9
# DBPort=None#27017
# MINIOPort=None#9010

# def init(ip,db_port,minio_port):
#     IP=ip
#     DBPort=db_port
#     MINIOPort=minio_port
#     os.system('.\cookie.exe  -b chrome -f json --dir results')


#默认无密码
import pymongo
DBIP = os.environ['DBIP']
MINIOIP = os.environ['MINIOIP']
DBPort = os.environ['DBPort']
MINIOPort = os.environ['MINIOPort']
db_client = pymongo.MongoClient(f"mongodb://{DBIP}:{DBPort}/")["db_weibo"]
db_proxy = pymongo.MongoClient(f"mongodb://{DBIP}:{DBPort}/")["db_proxy"]