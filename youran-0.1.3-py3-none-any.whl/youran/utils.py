import requests
import json
import logging

import os
import random,sys,datetime,time
from bs4 import BeautifulSoup
from tqdm import tqdm
import youran
from youran import db,net,utils
from youran.db import *
from youran.net import *
from youran.disks import Min

logger = logging.getLogger('main')
logger.setLevel(logging.DEBUG)
log = logging.StreamHandler()
log.setFormatter(logging.Formatter('%(levelname)s - %(asctime)s - %(message)s'))
logger.addHandler(log)
min = Min()
def download_media(mblog):
        # main.warning(mblog.keys())
    url_names = youran.net.img.extract(mblog)
    logger.warning(f'解析原微博中的图片：')
    for (url, name) in url_names:
        # name=mblog['bid']+name
        # name=mblog['bid']+name
        logger.warning(f'图片名称为:{name}')
        if min.exist(name):
            logger.warning('该图片存在，跳过。。。')
            return True
        logger.warning(f'开始下载图片，URL:{url}')
        content=youran.net.net.download(url,progress=True)
        if content is None:
            logger.warning('图片链接过时，跳过')
            return False
        min.save_weibo('imgs/'+name,content )
    video_url, video_name = youran.net.video.extract(mblog)
    logger.warning(f'解析原微博中的视频：')
    if video_name is not None:
        # video_name=mblog['bid']+video_name
        # name=video_name
        logger.warning(f'视频名称为:{video_name}')
        if min.exist(video_name,t='videos'):
            logger.warning('该视频存在，跳过。。。')
            return True
        logger.warning(f'开始下载视频，URL:{video_url}')
        content=youran.net.net.download(video_url,progress=True)
        if content is None:
            logger.warning('视频链接过时，跳过')
            return False
        min.save_weibo('videos/'+video_name, content)
    return True

def download_mblog(mblog,uid,current_page,total_page,duplicate=False,cookie=False,proxy=False):
    ttime=time.time()
    # uid=mblog['user']['id'] 
    # mblog['bid']=mblog['mblogid']
    if db.mblog.exists(mblog['bid']) and not duplicate:
        logger.warning(f'({uid}:{current_page}/{total_page})-------bid为{mblog["bid"]}的博文已存在，跳过')
        # logger.warning(f'({uid}:{current_page}/{total_page})-------bid为{mblog["bid"]}的博文已存在，跳过')
        return
    logger.warning(f'({uid}:{current_page}/{total_page})-------开始解析bid为{mblog["bid"]}的博文')
    # logger.warning(f'({uid}:{current_page}/{total_page})-------开始解析bid为{mblog["bid"]}的博文')
    mblog = youran.net.mblog.get(mblog,cookie=cookie,proxy=proxy)
    if type(mblog)==tuple:
        logger.error(f'({uid}:{current_page}/{total_page})-------解析{mblog}出错........')
        logger.error(f'({uid}:{current_page}/{total_page})-------停止解析本博文')
        logger.warning('*'*100)
        return
    mblog['uid']=uid
    mblog['spider_time']=time.time()
    if mblog is not None:
        logger.warning(f'({uid}:{current_page}/{total_page})-------解析到内容为：{utils.cleanhtml(mblog["text"])}')
        logger.warning(f'({uid}:{current_page}/{total_page})-------添加到数据库中..')
        if db.mblog.add(mblog):
            logger.warning(f'({uid}:{current_page}/{total_page})-------添加到数据库中成功..')
        else:
            logger.warning(f'({uid}:{current_page}/{total_page})-------添加到数据库中失败，错误原因：重复bid..')
        logger.warning(f'({uid}:{current_page}/{total_page})-------开始解析评论..')
        comments =None
        try:
            comments= youran.net.comment.get(mblog,cookie=cookie,proxy=proxy)
        except Exception as e:
            print(str(e))
        if comments is not None:
            if 'data' in comments :
                if 'data' in comments['data']:
                    logger.warning(f'({uid}:{current_page}/{total_page})-------解析到原微博中评论：{comments["data"]["data"][0]["text"]}')
            db.comment.add(comments)
        logger.warning(f'({uid}:{current_page}/{total_page})-------解析视频：')
        try:
            download_media(mblog)
        except Exception as e:
            logger.error('error.....retry download............')
            logger.error(repr(mblog))
    else:
        logger.warning(f'({uid}:{current_page}/{total_page})-------博文为空,停止解析本博文')
        logger.warning('*'*100)
        return
    # spider_mblogs+=1
    logger.warning(f'({uid}:{current_page}/{total_page})-------开始解析转发的微博........')
    if 'retweeted_status' in mblog.keys():
        rblog = mblog['retweeted_status']
        # rblog['bid']=rblog['mblogid']
        if youran.db.mblog.exists(rblog['bid']):
            logger.warning(f'({uid}:{current_page}/{total_page})-------bid为{rblog["bid"]}的博文已存在，跳过')
            return
        rblog = youran.net.mblog.get(rblog,cookie,proxy)
        if type(rblog)==tuple or rblog is None:
            logger.error(f'({uid}:{current_page}/{total_page})-------解析{rblog}出错........')
            logger.error(f'({uid}:{current_page}/{total_page})-------停止解析本博文')
            logger.warning('*'*100)
            return
        logger.warning(f'({uid}:{current_page}/{total_page})-------开始解析bid为{rblog["bid"]}的转发博文')
        # logger.warning(rblog.keys())
        if rblog['user'] is not None:
            rblog['uid']=rblog['user']['id'] 
        rblog['spider_time']=time.time()
        if rblog is not None:
            logger.warning(f'({uid}:{current_page}/{total_page})-------解析转发微博的内容：{utils.cleanhtml(rblog["text"])}')
            logger.warning(f'({uid}:{current_page}/{total_page})-------添加到数据库中..')
            if youran.db.mblog.add(rblog):
                logger.warning(f'({uid}:{current_page}/{total_page})-------添加到数据库中成功..')
            else:
                logger.warning(f'({uid}:{current_page}/{total_page})-------添加到数据库中失败，错误原因：重复bid..')
            logger.warning(f'({uid}:{current_page}/{total_page})-------开始解析评论..')
            rcomments = youran.net.comment.get(rblog,cookie=cookie,proxy=proxy)
            if rcomments is not None:
                if 'data' in rcomments :
                    if 'data' in rcomments['data']:
                        logger.warning(f'({uid}:{current_page}/{total_page})-------解析到转发微博中评论：{rcomments["data"]["data"][0]["text"]}')
                youran.db.comment.add(rcomments)
            logger.warning(f'({uid}:{current_page}/{total_page})-------解析视频：')
            try:
                download_media(rblog)
            except Exception as e:
                logger.error('error.....retry download............')
                logger.error(repr(rblog))
    # utils.sleep(1,2)
    # print()
    speeed=1/(time.time()-ttime)
    logger.warning(f'({uid}:{current_page}/{total_page})-------抓取速度为：'+str(speeed)+'条/秒')
def sleep(s=10,e=30):
    sleep_time = random.randint(s, e)
    for t in [_ for _ in range(0, sleep_time)][::-1]:
        sys.stdout.write(f'\r{str(datetime.datetime.now())},sleep {t} seconds....')
        time.sleep(1)
        sleep_time-=1
    # print('\n')
def download_hot():
    hots=youran.net.hot.get()
    items=[(hot[0],hot[1]) for hot in hots]
    if db.hot.add({'items':items}):
        logger.warning('更新当前热点成功：')
        logger.warning(items)
    for hot in hots:
        bids=hot[2]
        url=hot[1]
        # print(url,bids)
        logger.warning(f'热点链接：{url},bids:{bids}')
        db.hotids.add({'url':url,'bids':bids})
        for bid in bids:
            download_mblog({'bid':bid,'isLongText':True},'uid','current_page','total_page',duplicate=True)
import re
def cleanhtml(raw_html):
    cleantext = BeautifulSoup(raw_html, "lxml").text
    return cleantext




if __name__ == '__main__':
    print()
